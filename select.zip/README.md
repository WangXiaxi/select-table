# select

基于element扩展的下拉表格组件

> select-table

## Build Setup

``` bash
# param
'value', // v-model接受值 多选请传数组
'size', // 同 element size
'valName', // 显示词
'valKey', // 值
'tableConfig', // 表头配置
'options', // options配置
'multiple', // 是否多选
'clearable', // 是否显示清除按钮
'placeholder' // placeholder
```

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
